<?php $__env->startSection('title', 'Top Up Saldo'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gray-50 py-8">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Header -->
        <div class="mb-8">
            <div class="flex items-center space-x-4">
                <a href="<?php echo e(route('user.transactions.index')); ?>" class="text-gray-600 hover:text-gray-900">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                    </svg>
                </a>
                <div>
                    <h1 class="text-3xl font-bold text-gray-900">Top Up Saldo</h1>
                    <p class="text-gray-600 mt-2">Tambahkan saldo untuk membeli kursus</p>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Top Up Form -->
            <div class="lg:col-span-2">
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-semibold text-gray-900 mb-6">Pilih Jumlah Top Up</h2>
                    
                    <form action="<?php echo e(route('user.transactions.topup.process')); ?>" method="POST" id="topupForm">
                        <?php echo csrf_field(); ?>
                        
                        <!-- Amount Selection -->
                        <div class="mb-6">
                            <label class="block text-sm font-medium text-gray-700 mb-3">Jumlah Top Up</label>
                            <div class="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
                                <button type="button" onclick="selectAmount(50000)" class="amount-btn p-4 border-2 border-gray-200 rounded-lg text-center hover:border-blue-500 hover:bg-blue-50 transition-colors">
                                    <div class="font-semibold text-gray-900">Rp 50.000</div>
                                </button>
                                <button type="button" onclick="selectAmount(100000)" class="amount-btn p-4 border-2 border-gray-200 rounded-lg text-center hover:border-blue-500 hover:bg-blue-50 transition-colors">
                                    <div class="font-semibold text-gray-900">Rp 100.000</div>
                                </button>
                                <button type="button" onclick="selectAmount(250000)" class="amount-btn p-4 border-2 border-gray-200 rounded-lg text-center hover:border-blue-500 hover:bg-blue-50 transition-colors">
                                    <div class="font-semibold text-gray-900">Rp 250.000</div>
                                </button>
                                <button type="button" onclick="selectAmount(500000)" class="amount-btn p-4 border-2 border-gray-200 rounded-lg text-center hover:border-blue-500 hover:bg-blue-50 transition-colors">
                                    <div class="font-semibold text-gray-900">Rp 500.000</div>
                                </button>
                                <button type="button" onclick="selectAmount(1000000)" class="amount-btn p-4 border-2 border-gray-200 rounded-lg text-center hover:border-blue-500 hover:bg-blue-50 transition-colors">
                                    <div class="font-semibold text-gray-900">Rp 1.000.000</div>
                                </button>
                                <button type="button" onclick="selectCustomAmount()" class="amount-btn p-4 border-2 border-gray-200 rounded-lg text-center hover:border-blue-500 hover:bg-blue-50 transition-colors">
                                    <div class="font-semibold text-gray-900">Jumlah Lain</div>
                                </button>
                            </div>
                            
                            <div class="relative">
                                <input type="number" 
                                       name="amount" 
                                       id="customAmount" 
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                                       placeholder="Masukkan jumlah (min. Rp 10.000)"
                                       min="10000"
                                       max="10000000"
                                       required>
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <span class="text-gray-500 text-sm">Rp</span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Payment Method -->
                        <div class="mb-6">
                            <label class="block text-sm font-medium text-gray-700 mb-3">Metode Pembayaran</label>
                            <img src="<?php echo e(asset('error.png')); ?>" alt="Gopay" class="w-1/2 mx-auto">

                            
                            <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Submit Button -->
                        
                    </form>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="lg:col-span-1">
                <!-- Current Balance -->
                <div class="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-lg shadow-lg p-6 text-white mb-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-blue-100 text-sm">Saldo Saat Ini</p>
                            <p class="text-2xl font-bold">Rp <?php echo e(number_format(auth()->user()->balance, 0, ',', '.')); ?></p>
                        </div>
                        <div class="p-3 bg-white bg-opacity-20 rounded-full">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
                            </svg>
                        </div>
                    </div>
                </div>

                <!-- Information -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Informasi Top Up</h3>
                    <div class="space-y-4">
                        <div class="flex items-start">
                            <svg class="w-5 h-5 text-blue-600 mt-0.5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                            <div>
                                <p class="text-sm font-medium text-gray-900">Minimum Top Up</p>
                                <p class="text-xs text-gray-500">Rp 10.000</p>
                            </div>
                        </div>
                        <div class="flex items-start">
                            <svg class="w-5 h-5 text-green-600 mt-0.5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                            <div>
                                <p class="text-sm font-medium text-gray-900">Proses Instan</p>
                                <p class="text-xs text-gray-500">E-Wallet & Kartu Kredit</p>
                            </div>
                        </div>
                        <div class="flex items-start">
                            <svg class="w-5 h-5 text-yellow-600 mt-0.5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                            <div>
                                <p class="text-sm font-medium text-gray-900">Aman & Terpercaya</p>
                                <p class="text-xs text-gray-500">Transaksi dilindungi SSL</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Transactions -->
                <div class="bg-white rounded-lg shadow-md p-6 mt-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Transaksi Terakhir</h3>
                    <div class="space-y-3">
                        <?php
                            $recentTransactions = auth()->user()->transactions()->latest()->take(3)->get();
                        ?>
                        <?php $__empty_1 = true; $__currentLoopData = $recentTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="flex items-center justify-between py-2 border-b border-gray-100 last:border-b-0">
                                <div>
                                    <p class="text-sm font-medium text-gray-900">
                                        <?php if($transaction->type === 'topup'): ?>
                                            Top Up
                                        <?php else: ?>
                                            <?php echo e(ucfirst($transaction->type)); ?>

                                        <?php endif; ?>
                                    </p>
                                    <p class="text-xs text-gray-500"><?php echo e($transaction->created_at->format('d/m/Y')); ?></p>
                                </div>
                                <div class="text-right">
                                    <p class="text-sm font-medium <?php echo e($transaction->type === 'topup' ? 'text-green-600' : 'text-red-600'); ?>">
                                        <?php echo e($transaction->type === 'topup' ? '+' : '-'); ?>Rp <?php echo e(number_format($transaction->amount, 0, ',', '.')); ?>

                                    </p>
                                    <p class="text-xs <?php echo e($transaction->status === 'success' ? 'text-green-500' : ($transaction->status === 'pending' ? 'text-yellow-500' : 'text-red-500')); ?>">
                                        <?php echo e(ucfirst($transaction->status)); ?>

                                    </p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-sm text-gray-500 text-center py-4">Belum ada transaksi</p>
                        <?php endif; ?>
                    </div>
                    <div class="mt-4">
                        <a href="<?php echo e(route('user.transactions.index')); ?>" class="text-blue-600 hover:text-blue-700 text-sm font-medium">
                            Lihat Semua →
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function selectAmount(amount) {
    // Remove active class from all buttons
    document.querySelectorAll('.amount-btn').forEach(btn => {
        btn.classList.remove('border-blue-500', 'bg-blue-50');
        btn.classList.add('border-gray-200');
    });
    
    // Add active class to clicked button
    event.target.closest('.amount-btn').classList.remove('border-gray-200');
    event.target.closest('.amount-btn').classList.add('border-blue-500', 'bg-blue-50');
    
    // Set the amount in input
    document.getElementById('customAmount').value = amount;
}

function selectCustomAmount() {
    // Remove active class from all buttons
    document.querySelectorAll('.amount-btn').forEach(btn => {
        btn.classList.remove('border-blue-500', 'bg-blue-50');
        btn.classList.add('border-gray-200');
    });
    
    // Add active class to custom button
    event.target.closest('.amount-btn').classList.remove('border-gray-200');
    event.target.closest('.amount-btn').classList.add('border-blue-500', 'bg-blue-50');
    
    // Clear and focus input
    document.getElementById('customAmount').value = '';
    document.getElementById('customAmount').focus();
}

// Format number input
document.getElementById('customAmount').addEventListener('input', function(e) {
    // Remove active class from preset buttons when typing custom amount
    if (e.target.value) {
        document.querySelectorAll('.amount-btn').forEach(btn => {
            btn.classList.remove('border-blue-500', 'bg-blue-50');
            btn.classList.add('border-gray-200');
        });
        
        // Activate custom amount button
        document.querySelectorAll('.amount-btn')[5].classList.remove('border-gray-200');
        document.querySelectorAll('.amount-btn')[5].classList.add('border-blue-500', 'bg-blue-50');
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u714926127/domains/codestep.site/public_html/resources/views/user/topup.blade.php ENDPATH**/ ?>