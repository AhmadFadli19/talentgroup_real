<?php $__env->startSection('title', 'Kursus Saya'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-4xl mx-auto bg-white p-8 rounded shadow">
        <h1 class="text-2xl font-bold mb-6">Kursus Saya</h1>
        <?php if($courses->isEmpty()): ?>
            <div class="text-center py-8">
                <div class="text-gray-400 text-6xl mb-4">
                    <i class="fas fa-graduation-cap"></i>
                </div>
                <p class="text-gray-600 text-lg mb-4">Anda belum memiliki kursus.</p>
                <a href="<?php echo e(route('user.courses.index')); ?>" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors">
                    Jelajahi Kursus
                </a>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border rounded-lg p-6 hover:shadow-lg transition-shadow">
                        <div class="flex justify-between items-start mb-4">
                            <div class="flex-1">
                                <h2 class="text-xl font-semibold mb-2"><?php echo e($course->title); ?></h2>
                                <p class="text-gray-600 mb-3"><?php echo e($course->description); ?></p>
                                
                                <!-- Progress Bar -->
                                <div class="mb-3">
                                    <div class="flex justify-between text-sm text-gray-600 mb-1">
                                        <span>Progress</span>
                                        <span><?php echo e($course->progress ?? 0); ?>%</span>
                                    </div>
                                    <div class="w-full bg-gray-200 rounded-full h-2">
                                        <div class="bg-blue-600 h-2 rounded-full" style="width: <?php echo e($course->progress ?? 0); ?>%"></div>
                                    </div>
                                </div>
                                
                                <!-- Status Badge -->
                                <?php if($course->is_completed ?? false): ?>
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                        <i class="fas fa-check-circle mr-1"></i>
                                        Selesai
                                    </span>
                                <?php else: ?>
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                        <i class="fas fa-play-circle mr-1"></i>
                                        Sedang Belajar
                                    </span>
                                <?php endif; ?>
                                
                                <!-- Enrollment Date -->
                                <?php if($course->enrolled_at): ?>
                                    <p class="text-xs text-gray-500 mt-2">
                                        Terdaftar: <?php echo e($course->enrolled_at->format('d M Y')); ?>

                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="flex space-x-3">
                            <a href="<?php echo e(route('user.courses.learn', $course->id)); ?>"
                                class="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 text-center transition-colors">
                                <?php if($course->is_completed ?? false): ?>
                                    Lihat Ulang
                                <?php else: ?>
                                    Lanjutkan Belajar
                                <?php endif; ?>
                            </a>
                            
                            <?php if($course->is_completed ?? false): ?>
                                <a href="<?php echo e(route('user.courses.results', $course->id)); ?>"
                                    class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                                    Hasil
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u714926127/domains/codestep.site/public_html/resources/views/user/my_courses.blade.php ENDPATH**/ ?>