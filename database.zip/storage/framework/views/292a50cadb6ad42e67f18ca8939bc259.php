<?php $__env->startSection('title', $course->title); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-2xl mx-auto bg-white p-8 rounded shadow">
        <h1 class="text-2xl font-bold mb-4"><?php echo e($course->title); ?></h1>
        <p class="text-gray-700 mb-4"><?php echo e($course->description); ?></p>
        <p class="text-blue-700 font-bold mb-6">Rp <?php echo e(number_format($course->price, 0, ',', '.')); ?></p>

        <?php if($isEnrolled): ?>
            <a href="<?php echo e(route('user.courses.learn', $course->id)); ?>"
                class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Mulai Belajar</a>
        <?php else: ?>
            <form method="POST" action="<?php echo e(route('user.courses.purchase', $course->id)); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Beli Kursus</button>
            </form>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u714926127/domains/codestep.site/public_html/resources/views/user/courses_show.blade.php ENDPATH**/ ?>