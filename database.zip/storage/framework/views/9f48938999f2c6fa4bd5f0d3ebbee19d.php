<?php $__env->startSection('title', 'Daftar Kursus'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-4xl mx-auto bg-white p-8 rounded shadow">
        <h1 class="text-2xl font-bold mb-6">Daftar Kursus</h1>
        <?php if($courses->isEmpty()): ?>
            <p class="text-gray-600">Belum ada kursus tersedia.</p>
        <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border rounded p-4 flex flex-col justify-between">
                        <div>
                            <h2 class="text-lg font-semibold mb-2"><?php echo e($course->title); ?></h2>
                            <p class="text-gray-600 mb-2"><?php echo e($course->description); ?></p>
                            <?php if($course->price < 1): ?>
                            <p class="text-green-400 font-bold mb-4 mt-12 px-2 py-1 rounded-md flex justify-end">GRATIS</p>
                            <?php else: ?>
                            <p class="text-blue-700 font-bold mb-4 mt-12 px-2 py-1 rounded-md flex justify-end">Rp <?php echo e(number_format($course->price, 0, ',', '.')); ?></p>
                            <?php endif; ?>
                        </div>
                        <a href="<?php echo e(route('user.courses.show', $course->id)); ?>"
                            class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 text-center">Detail</a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u714926127/domains/codestep.site/public_html/resources/views/user/courses_index.blade.php ENDPATH**/ ?>