    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Detail Form - <?php echo e($BannerCard->title); ?></title>
        <script src="https://cdn.tailwindcss.com"></script>
    </head>

    <body class="bg-gray-100 p-6">
        <div class="max-w-3xl mx-auto bg-white p-6 rounded shadow">
            <h2 class="text-xl font-bold mb-4">Isi Detail Konten: <?php echo e($BannerCard->title); ?></h2>

            <?php if(session('success')): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('bannercard.detail.submit', $BannerCard->id)); ?>" class="space-y-4" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                

                <div>
                    <label class="block mb-1 font-medium">Judul</label>
                    <input type="text" name="judul" class="w-full border p-2 rounded" value="<?php echo e(old('judul')); ?>"
                        required />
                </div>

                <div>
                    <label class="block mb-1 font-medium">Topik</label>
                    <textarea name="topic" rows="3" class="w-full border p-2 rounded"><?php echo e(old('topic')); ?></textarea>
                </div>

                <div>
                    <label class="block mb-1 font-medium">URL Kelas</label>
                    <input type="text" name="url_kelas" class="w-full border p-2 rounded"
                        value="<?php echo e(old('url_kelas')); ?>">
                </div>

                <div>
                    <label class="block mb-1 font-medium">Judul Deskripsi</label>
                    <input type="text" name="judul_description" class="w-full border p-2 rounded"
                        value="<?php echo e(old('judul_description')); ?>">
                </div>

                <div>
                    <label class="block mb-1 font-medium">Deskripsi Kelas</label>
                    <textarea name="description_kelas" rows="3" class="w-full border p-2 rounded"><?php echo e(old('description_kelas')); ?></textarea>
                </div>

                <div>
                    <label class="block mb-1 font-medium">Target</label>
                    <textarea name="target" rows="3" class="w-full border p-2 rounded"><?php echo e(old('target')); ?></textarea>
                </div>

                <div>
                    <label class="block mb-1 font-medium">Sasaran</label>
                    <textarea name="sasaran" rows="3" class="w-full border p-2 rounded"><?php echo e(old('sasaran')); ?></textarea>
                </div>
                <div class="flex gap-4">
                    <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded">
                        Simpan Konten
                    </button>
                    <a href="<?php echo e(url('/' . $BannerCard->id)); ?>"
                        class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded">
                        Lihat Preview
                    </a>
                </div>
            </form>
        </div>
    </body>

    </html>
<?php /**PATH /home/u714926127/domains/codestep.site/public_html/resources/views/admin/content/banner/detail-form.blade.php ENDPATH**/ ?>