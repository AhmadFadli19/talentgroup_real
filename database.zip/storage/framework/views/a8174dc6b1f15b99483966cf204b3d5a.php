<?php $__env->startSection('content'); ?>
    <section class="ln-latest-news-section">
        <div class="ln-container">
          <!-- Heading -->
          <div class="ln-row ln-align-items-center ln-mb-5">
            <div class="ln-col-lg-6">
              <div class="ln-section-heading">
                <h2>
                  Check Out What Is <em>Trending</em> In Our Latest <span>News</span>
                </h2>
              </div>
            </div>
          </div>
      
          <!-- Main Content -->
          <div class="ln-row ln-gy-4">
            <!-- Left Banner -->
            <?php $__currentLoopData = $kolaborasi->where('category', 'Upbanner'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="ln-col-lg-6">
              <div class="ln-left-image-card">
                <img src="<?php echo e(asset('storage/' . $item->image)); ?>" alt="<?php echo e($item->title); ?>" />
                <div class="ln-info-box">
                  <ul class="ln-meta-info">
                    <li><i class="fa fa-calendar"></i> 24 Mar 2021</li>
                    <li><i class="fa fa-users"></i> TemplateMo</li>
                    <li><i class="fa fa-folder"></i> Branding</li>
                  </ul>
                  <h4>SEO Agency &amp; Digital Marketing</h4>
                  <p>Lorem ipsum dolor sit amet, consectetur and sed doer ket eismod tempor incididunt ut labore et dolore magna...</p>
                  <a href="#" class="ln-main-btn">Discover More</a>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
            <!-- Right Blog List -->
            <div class="ln-col-lg-6">
              <div class="ln-blog-list">
                <!-- Blog Item -->
                <?php $__currentLoopData = $kolaborasi->where('category', 'Downbanner'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="ln-blog-item">
                  <div class="ln-content">
                    <span><i class="fa fa-calendar"></i> 18 Mar 2021</span>
                    <h5><a href="kolaborasi/<?php echo e($item->create_view); ?>">New Websites &amp; Backlinks</a></h5>
                    <p>Lorem ipsum dolor sit amsecteturii and sed doer ket eismod...</p>
                  </div>
                  <div class="ln-thumb">
                    <img src="<?php echo e(asset('storage/' . $item->image )); ?>" alt="Blog Image" />
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </div>
        </div>
      </section>
      
    
    <div style="margin-top: 200px;">
        <section class="skilvul-section">
            <div class="container">
                <div class="content">
                    <div class="image-wrapper">
                        <img src="<?php echo e(asset('assets/images/Perkumpulan.jpg')); ?>" alt="talentgruop Image" />
                    </div>
                    <div class="text-wrapper">
                        <h1>
                            TalentGroup Percaya Bahwa Pendidikan Adalah Kunci Bagi <br />
                            Kemajuan Indonesia
                        </h1>
                        <p>
                            TalentGroup memiliki mimpi yang sedang direalisasikan untuk mencetak
                            <strong>1 Juta Talenta Digital</strong> yang kompeten, kreatif, dan
                            berdaya saing tinggi, siap untuk menghadapi tantangan dan peluang di era digital.
                        </p>
                        <div class="stats">
                            <div class="stat">
                                <h2>136K+</h2>
                                <p>Talenta Digital</p>
                            </div>
                            <div class="divider"></div>
                            <div class="stat">
                                <h2>74</h2>
                                <p>Total Partner</p>
                            </div>
                            <div class="divider"></div>
                            <div class="stat">
                                <h2>44</h2>
                                <p>Total Program</p>
                            </div>
                            <div class="divider"></div>
                            <div class="stat">
                                <h2>33</h2>
                                <p>Total Kelas</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u714926127/domains/codestep.site/public_html/resources/views/Home/partnerkolaborasi.blade.php ENDPATH**/ ?>