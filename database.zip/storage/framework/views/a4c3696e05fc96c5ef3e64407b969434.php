<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href=<?php echo e(asset('assets/css/home.css')); ?>>
    <link rel="stylesheet" href=<?php echo e(asset('assets/css/blog.css')); ?>>
    <link rel="stylesheet" href=<?php echo e(asset('assets/css/about.css')); ?>>
    <link rel="stylesheet" href=<?php echo e(asset('assets/css/bartnerkolabolaborasi.css')); ?>>

    <link href="https://cdn.jsdelivr.net/npm/flowbite@3.1.2/dist/flowbite.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />



    <title>TalentGroup</title>

</head>
<body>
    <?php echo $__env->make('Content/header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('Content/footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- Scripts -->
    
</body>

</html><?php /**PATH /home/u714926127/domains/codestep.site/public_html/resources/views/layout.blade.php ENDPATH**/ ?>