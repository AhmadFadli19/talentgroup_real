<?php $__env->startSection('content'); ?>
<!-- BANNER -->



    

    <section class="blog-section-cards">
        <?php $__currentLoopData = $slideblogger; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="blog-card">
            <div class="blog-card-img">
                <img src="<?php echo e(asset('storage/' . $item->image)); ?>" alt="<?php echo e($item->title); ?>" />
            </div>
            <div class="blog-card-content">
                <p class="blog-author"><?php echo e($item->blog_author); ?> | <?php echo e($item->created_at); ?></p>
                <h3 class="blog-title"><?php echo e($item->title); ?></h3>
                <p class="blog-desc"><?php echo e($item->description); ?></p>
                <a href="slideblogger/<?php echo e($item->create_view); ?>" class="blog-btn">Baca Selengkapnya</a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u714926127/domains/codestep.site/public_html/resources/views/Home/blog.blade.php ENDPATH**/ ?>